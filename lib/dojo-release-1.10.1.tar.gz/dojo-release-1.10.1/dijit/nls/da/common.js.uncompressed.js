define(
"dijit/nls/da/common", ({
	buttonOk: "OK",
	buttonCancel: "Annullér",
	buttonSave: "Gem",
	itemClose: "Luk"
})
);
