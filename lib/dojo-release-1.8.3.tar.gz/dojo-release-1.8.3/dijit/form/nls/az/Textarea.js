//>>built
define("dijit/form/nls/az/Textarea",({"iframeEditTitle":"Redaktə sahəsi","iframeFocusTitle":"Redaktə sahəsi çərçivəsi"}));
