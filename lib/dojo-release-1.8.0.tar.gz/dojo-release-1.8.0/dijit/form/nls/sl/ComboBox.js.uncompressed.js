define(
"dijit/form/nls/sl/ComboBox", ({
		previousMessage: "Prejšnje izbire",
		nextMessage: "Dodatne izbire"
})
);
