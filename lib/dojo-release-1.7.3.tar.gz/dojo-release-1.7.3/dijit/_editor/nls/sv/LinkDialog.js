//>>built
define("dijit/_editor/nls/sv/LinkDialog",({createLinkTitle:"Länkegenskaper",insertImageTitle:"Bildegenskaper",url:"URL-adress:",text:"Beskrivning:",target:"Mål:",set:"Ange",currentWindow:"aktuellt fönster",parentWindow:"överordnat fönster",topWindow:"översta fönstret",newWindow:"nytt fönster"}));
