define(
"dijit/_editor/nls/nb/LinkDialog", //begin v1.x content
({
	createLinkTitle: "Koblingsegenskaper",
	insertImageTitle: "Bildeegenskaper",
	url: "URL:",
	text: "Beskrivelse:",
	target: "Mål:",
	set: "Definer",
	currentWindow: "Gjeldende vindu",
	parentWindow: "Overordnet vindu",
	topWindow: "Øverste vindu",
	newWindow: "Nytt vindu"
})

//end v1.x content
);
