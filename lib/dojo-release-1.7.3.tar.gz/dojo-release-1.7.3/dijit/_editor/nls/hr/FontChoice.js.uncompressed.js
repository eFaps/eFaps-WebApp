define(
"dijit/_editor/nls/hr/FontChoice", ({
	fontSize: "Veličina",
	fontName: "Font",
	formatBlock: "Oblikovanje",
	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "jednaki razmak",
	cursive: "rukopisni",
	fantasy: "fantastika",
	noFormat: "Nijedan",
	p: "Odlomak",
	h1: "Naslov",
	h2: "Podnaslov",
	h3: "Pod-podnaslov",
	pre: "Prethodno formatirano",
	1: "vrlo vrlo malo",
	2: "vrlo malo",
	3: "malo",
	4: "srednje",
	5: "veliko",
	6: "vrlo veliko",
	7: "vrlo vrlo veliko"
})
);
