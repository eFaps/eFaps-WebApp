define(
"dijit/form/nls/sv/validate", //begin v1.x content
({
	invalidMessage: "Det angivna värdet är ogiltigt.",
	missingMessage: "Värdet är obligatoriskt.",
	rangeMessage: "Värdet är utanför intervallet."
})
//end v1.x content
);
