define(
"dijit/form/nls/sv/ComboBox", //begin v1.x content
({
		previousMessage: "Föregående alternativ",
		nextMessage: "Fler alternativ"
})
//end v1.x content
);
