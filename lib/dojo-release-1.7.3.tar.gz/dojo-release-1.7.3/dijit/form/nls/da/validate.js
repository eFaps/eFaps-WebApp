//>>built
define("dijit/form/nls/da/validate",({invalidMessage:"Den angivne værdi er ikke gyldig.",missingMessage:"Værdien er påkrævet.",rangeMessage:"Værdien er uden for intervallet."}));
