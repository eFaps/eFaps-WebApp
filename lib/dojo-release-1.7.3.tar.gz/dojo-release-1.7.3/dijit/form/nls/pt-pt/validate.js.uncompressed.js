define(
"dijit/form/nls/pt-pt/validate", //begin v1.x content
({
	invalidMessage: "O valor introduzido não é válido.",
	missingMessage: "Este valor é requerido.",
	rangeMessage: "Este valor encontra-se fora do intervalo."
})
//end v1.x content
);
