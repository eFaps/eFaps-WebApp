define(
"dijit/form/nls/he/ComboBox", //begin v1.x content
({
		previousMessage: "האפשרויות הקודמות",
		nextMessage: "אפשרויות נוספות"
})
//end v1.x content
);
