//>>built
define("dijit/form/nls/hr/ComboBox",({previousMessage:"Prethodni izbori",nextMessage:"Više izbora"}));
