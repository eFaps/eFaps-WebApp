define(
"dijit/form/nls/cs/ComboBox", //begin v1.x content
({
		previousMessage: "Předchozí volby",
		nextMessage: "Další volby"
})
//end v1.x content
);
